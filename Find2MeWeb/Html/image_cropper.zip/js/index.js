var $uploadCrop,
    tempFilename,
    rawImg,
    imageId;

function readFile(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function (e) {
            $('.upload-demo').addClass('ready');
            $('#cropImagePop').modal('show');
            rawImg = e.target.result;
        }
        reader.readAsDataURL(input.files[0]);
    } else {
        console.log("Sorry - you're browser doesn't support the FileReader API");
    }
}

$uploadCrop = $('#upload-demo').croppie({
    viewport: {
        width: 300, // croper middle box width
        height: 300, // croper middle box height
    },
    enforceBoundary: true,
    enableExif: true
});

 
$('#cropImagePop').on('shown.bs.modal', function () { // this function will fire ehn popup will open
    $uploadCrop.croppie('bind', {
        url: rawImg
    }).then(function () {
        console.log('jQuery bind complete');
    });
});


$('.item-img').on('change', function () { //this function will fire when image will change 
    imageId = $(this).data('id');
    tempFilename = $(this).val();
    $('#cancelCropBtn').data('id', imageId);
    readFile(this);
});

$('#cropImageBtn').on('click', function (ev) {
    $uploadCrop.croppie('result', {
        type: 'base64', // in which format you want 
        format: 'jpeg', // in which extention you want ?
    }).then(function (resp) {
        console.log(resp) // cropped image base64 data
        $('#cropImagePop').modal('hide'); //model popup will hide when user click on crop button
        $.ajax({
            url:"/",
            method:'POST',
            data:{
                image:resp // here we send image base64 data with 'image' parameters and you can send other params also 
            },
            success:function(data){ // this function will fire when you get success from server
                console.log(data)
            },
            error:function(error){ // this function will fire when you get an error from server
                console.log(error)
            },
            complete :function(data){ // this function will fire ajax from server
                console.log(data)
            }
        })
    });
});
